<form action="<?php echo base_url()?>ApplyOnline/insertApplicationForm2" method="post" class="registration-form form-horizontal">
    <div class="form-group">
        <label class="control-label col-md-2">Qualification:</label>
        <div class="col-md-10">
            <input type="text" class="form-control" id="" name="qualification[]">
        </div>
    </div>

    <div class="form-group">
        <label class="control-label col-md-2">Institution:</label>
        <div class="col-md-10">
            <input type="text" class="form-control" id="" name="institution[]">
        </div>
    </div>

    <div class="form-group">
        <label class="control-label col-md-2">Start Date:</label>
        <div class="col-md-10">
            <input type="date" class="form-control" id="" name="startdate[]">
        </div>
    </div>

    <div class="form-group">
        <label class="control-label col-md-2">End Date:</label>
        <div class="col-md-10">
            <input type="date" class="form-control" id="" name="enddate[]">
        </div>
    </div>

    <div class="form-group">
        <label class="control-label col-md-2">Grade:</label>
        <div class="col-md-10">
            <input type="text" class="form-control" id="" name="grade[]">
        </div>
    </div>
</form>
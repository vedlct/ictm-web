
<!DOCTYPE HTML>
<html>
	

<head>
		<title>icon college</title>
		<link href="<?php echo  base_url()?>public/stylesheets/style3.css" rel="stylesheet" type="text/css"  media="all" />
	</head>
	<body>
		<!--start-wrap--->
		<div class="wrap">
			<!---start-header---->
				<div class="header">
					<div class="logo">
						<h1><a href="#">Ohh</a></h1>
					</div>
				</div>
				<!---728x90--->
			<!---End-header---->
			<!--start-content------>
			<div class="content">
				<img src="<?php echo base_url()?>public/images/error-img.png" title="error" />
				<!---728x90--->
				<p><span><label>O</label>hh.....</span>You Requested the page that is no longer There.</p>
				
				<a href="<?php echo base_url()?>Home">Back To Home</a>
				<!---728x90--->

   			</div>
			<!--End-Cotent------>
		</div>
		<!--End-wrap--->
	</body>

</html>


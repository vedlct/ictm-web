										
                                        
                                        <!-- TEXT -->
                                        
                                        <div class="form-group">
                                        	<label class="control-label col-md-2">:</label>
                                          	<div class="col-md-10">
                                            	<input type="text" class="form-control" id="" name="">
                                          	</div>
				                        </div>
                                        
                                        <!-- EMAIL -->
                                        
                                        <div class="form-group">
                                        	<label class="control-label col-md-2">:</label>
                                          	<div class="col-md-10">
                                            	<input type="email" class="form-control" id="" name="">
                                          	</div>
				                        </div>
                                        
                                        <!-- TEXTAREA -->
                                        
                                        <div class="form-group">
                                        	<label class="control-label col-md-2">:</label>
                                          	<div class="col-md-10">
                                            	<textarea id="comment-message" name="comment" rows="8" tabindex="4"></textarea>
                                          	</div>
				                        </div>
                                        
                                        <!-- SELECT -->
                                        
                                        <div class="form-group">
                                        	<label class="control-label col-md-2">:</label>
                                          	<div class="col-md-10">
                                            	<select style="width: 100%" name="">
                                                      <option value="" disabled selected>Select...</option>
                                                      <option value=""></option>
                                                      <option value=""></option>
                                                      <option value=""></option>
                                                      <option value=""></option>
                                                    </select> 
                                          	</div>
				                        </div>
                                        
                                        <!-- RADIO -->
                                        
                                        <div class="form-group">
                                        	<label class="control-label col-md-2">:</label>
                                          	<div class="col-md-10">
                                            	<input type="radio" name="" value=""> &nbsp;&nbsp;
                                                <input type="radio" name="" value=""> &nbsp;&nbsp;
                                                <input type="radio" name="" value=""> 
                                          	</div>
				                        </div>
                                        
                                        <!-- DATE --> 
                                        
                                        <div class="form-group">
                                        	<label class="control-label col-md-2">:</label>
                                          	<div class="col-md-10">
                                            	<input type="date" class="form-control" id="" name="">
                                          	</div>
				                        </div>
                                        
                                        
                                        
                                        
                                        <button type="button" class="btn btn-previous">Previous</button>
				                        <button type="submit" class="btn">Submit!</button>
                                        
                                        <div class="form-group">        
                                          <div class="col-sm-offset-2 col-md-10">
                                            <button type="button" class="btn btn-next">Next</button>
                                          </div>
                                        </div>
                                        
 
                                        <fieldset>
                                            <div class="form-top">
                                                <div class="form-top-left">
                                                    <h3></h3>
                                                </div>
                                                
                                                <div class="form-top-right">
                                                    <p>Step  / 8</p>
                                                </div>
                                            </div>
                                            <div class="form-bottom">
                                                
                                                
                                                <button type="button" class="btn btn-previous">Previous</button>
                                                <button type="button" class="btn btn-next">Next</button>
                                            </div>
                                        </fieldset>
                                        
                                        
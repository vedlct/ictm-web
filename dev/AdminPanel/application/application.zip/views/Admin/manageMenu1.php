<!DOCTYPE html>
<html lang="en">
<head>
    <?php include('head.php') ?>

</head>

<body>
<!-- container section start -->
<section id="container" class="">
    <!--header start-->
    <?php include ('topNavigation.php') ?>
    <!--header end-->

    <!--sidebar start-->
    <?php include('leftNavigation.php') ?>
    <!--main content start-->
    <section id="main-content">
        <section class="wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h3 class="page-header"><i class="fa fa-table"></i> Manage Event</h3>
                    <ol class="breadcrumb">
                        <li><i class="fa fa-home"></i><a href="<?php echo base_url()?>Admin/Home">Home</a></li>
                        <li><i class="fa fa-table"></i>Manage Event</li>

                    </ol>
                </div>
            </div>
            <!-- page start-->

            <?php if ($this->session->flashdata('successMessage')!=null){?>
                <div class="alert alert-success" align="center"><strong><?php echo $this->session->flashdata('successMessage');?></strong></div>
            <?php }?>

            <div class="row">
                <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Manage News

                        </header>
                        <div id="panel" class="panel-body">

<!---->
<!--                            <div class="panel panel-default">-->
<!--                                <div class="panel-heading">-->
<!--                                    <h3 class="panel-title" >Custom Filter : </h3>-->
<!--                                </div>-->
<!--                                <div class="panel-body">-->
<!--                                    <form id="form-filter" class="form-horizontal">-->
<!--                                        <div class="form-group">-->
<!--                                            <label for="country" class="col-sm-2 control-label">Menu Type</label>-->
<!--                                            <div class="col-sm-4">-->
<!--                                                <select class="form-control m-bot15" name="menuType" id="menuType" required>-->
<!--                                                    <option value="" selected>--><?php //echo SELECT_MENU_TYPE?><!--</option>-->
<!--                                                    --><?php //for ($i=0;$i<count(MENU_TYPE);$i++){?>
<!--                                                        <option value="--><?php //echo MENU_TYPE[$i]?><!--">--><?php //echo MENU_TYPE[$i]?><!--</option>-->
<!--                                                    --><?php //} ?>
<!--                                                </select>-->
<!--                                            </div>-->
<!--                                        </div>-->
<!---->
<!--                                    </form>-->
<!--                                </div>-->
<!--                            </div>-->


                            <div class="table table-responsive" style="overflow-x: inherit">

                                <form>
                                <div class="form-group">
                                    <label style="text-align: right" for="menuType" class="control-label col-md-4 col-sm-4"> Select A Menu Type: </label>
                                    <div class="m-bot15 col-md-4 col-sm-4">
                                    <select class="form-control" name="menuType" id="menuType" required>
                                        <option value="" selected><?php echo "All Menu"?></option>
                                        <?php for ($i=0;$i<count(MENU_TYPE);$i++){?>
                                            <option value="<?php echo MENU_TYPE[$i]?>"><?php echo MENU_TYPE[$i]?></option>
                                        <?php } ?>
                                    </select>
                                    </div>
                                </div>
                                </form>
                                
                                <table class="table  table-striped table-advance  table-bordered table-hover" id="myTable">

                                    <thead>
                                    <tr>
                                        <th style="background-color: #394A59; color: whitesmoke; text-align:left; width: 5%"> No</th>
                                        <th style="background-color: #394A59; color: whitesmoke; text-align:left; width: 15%"> Menu Title</th>
                                        <th style="background-color: #394A59; color: whitesmoke; text-align:left"> O N</th>
                                        <th style="background-color: #394A59; color: whitesmoke; text-align:left"> Menu Type</th>
                                        <th style="background-color: #394A59; color: whitesmoke; text-align:left"> Parent Menu</th>
                                        <th style="background-color: #394A59; color: whitesmoke; text-align:left"> Page Title</th>
                                        <th style="background-color: #394A59; color: whitesmoke; text-align:left"> Menu Status</th>
                                        <th style="background-color: #394A59; color: whitesmoke; text-align:left"> Inserted By</th>
                                        <th style="background-color: #394A59; color: whitesmoke; text-align:left"> Last Modified By</th>
                                        <th style="background-color: #394A59; color: whitesmoke; text-align:left"> Last Modified Date(Y-m-d T)</th>
                                        <th style="background-color: #394A59; color: whitesmoke; text-align:left"> Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    </tbody>
                                </table>

                            </div>
                        </div>

                    </section>
                </div>
            </div>
            <!-- page end-->

        </section>
    </section>
    <!--main content end-->

    <div class="text-right wrapper">
        <div class="credits">
            <a href="#">Icon College</a> by <a href="#">A2N</a>
        </div>
    </div>

</section>
<!-- container section end -->
<!-- javascripts -->

<?php include('js.php') ?>

</body>
</html>



<script type="text/javascript">

    var table;

    $(document).ready(function() {

        //datatables
        table = $('#myTable').DataTable({

            "processing": true, //Feature control the processing indicator.
            "serverSide": true, //Feature control DataTables' server-side processing mode.
            "order": [], //Initial no order.

            // Load data for the table's content from an Ajax source
            "ajax": {
                "url": "<?php echo base_url('Admin/Menu/ajax_list')?>",
                "type": "POST",
                "data": function ( data ) {
                    data.menuType = $('#menuType').val();

                }
            },

            //Set column definition initialisation properties.
            "columnDefs": [
                {
                    "targets": [ 0,3,4,5,6,7,8,9,10], //first column / numbering column
                    "orderable": false, //set not orderable
                },
            ],

            //for change search name
            "oLanguage": {

                "sSearch": "<span>Search By Menu Title:</span> " //search

            }



        });
        $('#menuType').change(function(){ //button filter event click
            table.ajax.reload();  //just reload table
        });

    });


    function selectid(x) {
        if (confirm("Are you sure you want to delete this Menu?")) {
            btn = $(x).data('panel-id');
            $.ajax({
                type:'POST',
                url:'<?php echo base_url("Admin/Menu/deleteMenu/")?>'+btn,
                data:{'menuid':btn},
                cache: false,
                success:function(data) {
                    if(data==0){
                        location.reload();
                    }
                    else
                    {
                        alert('Please Delete Menu-( '+data+' ) First !!');
                        location.reload();
                    }
                }
            });
        }
        else {
            window.location="<?php echo base_url()?>Admin/Menu/ManageMenu";
        }
    }



</script>


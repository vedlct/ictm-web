<!-- javascripts -->

 <script src="<?php echo base_url()?>public/js/jquery-1.12.4.js"></script>
<!--<script-->
<!--        src="https://code.jquery.com/jquery-1.12.4.min.js"-->
<!--        integrity="sha256-ZosEbRLbNQzLpnKIkEdrPv7lOy9C27hHQ+Xp8a4MxAQ="-->
<!--        crossorigin="anonymous"></script>-->


 <script src="<?php echo base_url()?>public/js/bootstrapV3.3.7.min.js"></script>

<!--<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>-->




<!-- nice scroll -->
<script src="<?php echo base_url()?>public/js/jquery.scrollTo.min.js"></script>
<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-scrollTo/1.4.6/jquery.scrollTo.min.js"></script>-->

<script src="<?php echo base_url()?>public/js/jquery.nicescroll.js" type="text/javascript"></script>
<!--custome script for all page-->
<script src="<?php echo base_url()?>public/js/scripts.js"></script>

<!-- data table -->

<script src="<?php echo base_url('public/js/datatables/js/jquery.dataTables.min.js')?>"></script>

<script src="<?php echo base_url('public/js/datatables/js/dataTables.bootstrap.min.js')?>"></script>


<script>
    var ckBaseUrl = "<?php echo base_url(); ?>";
</script>

